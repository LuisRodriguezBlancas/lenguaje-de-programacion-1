#include <iostream>
#include <string>
using namespace std;

class Empleado {
private:
    string nombre;
    string apellidoPaterno;
    string apellidoMaterno;
    string fechaNacimiento;

public:
    void CapturarDatos() {
        cout << "Ingrese el nombre: ";
        cin.ignore();
        getline(cin, nombre);

        cout << "Ingrese el apellido paterno: ";
        getline(cin, apellidoPaterno);

        cout << "Ingrese el apellido materno (dejar en blanco si no hay): ";
        getline(cin, apellidoMaterno);

        cout << "Ingrese la fecha de nacimiento (en formato dd/mm/aaaa): ";
        getline(cin, fechaNacimiento);
    }

    string CalcularRFC() {
        string rfc;

        rfc += apellidoPaterno[0];

        for (size_t i = 1; i < apellidoPaterno.length(); i++) {
            if (apellidoPaterno[i] == 'A' || apellidoPaterno[i] == 'E' ||
                apellidoPaterno[i] == 'I' || apellidoPaterno[i] == 'O' || apellidoPaterno[i] == 'U') {
                rfc += apellidoPaterno[i];
                break;
            }
        }

        rfc += (apellidoMaterno.empty()) ? 'X' : apellidoMaterno[0];
        rfc += (nombre.empty()) ? 'X' : nombre[0];

        rfc += fechaNacimiento.substr(8, 2);
        rfc += fechaNacimiento.substr(3, 2);
        rfc += fechaNacimiento.substr(0, 2);

        return rfc;
    }
};

int main() {
    Empleado empleado;
    empleado.CapturarDatos();

    string rfc = empleado.CalcularRFC();
    cout << "\nEl RFC del empleado es: " << rfc << endl;

    return 0;
}
