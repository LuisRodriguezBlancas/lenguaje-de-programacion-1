#include <iostream>
using namespace std;

int main() {
    double num1, num2;

    cout << "Escribe el primer número: ";
    cin >> num1;

    cout << "Escribe el segundo número: ";
    cin >> num2;

    double suma = num1 + num2;
    double resta = num1 - num2;
    double multiplicacion = num1 * num2;
    double division = num1 / num2;

    cout << "La suma es: " << suma << endl;
    cout << "La resta es: " << resta << endl;
    cout << "La multiplicación es: " << multiplicacion << endl;
    cout << "La división es: " << division << endl;

    return 0;
}
